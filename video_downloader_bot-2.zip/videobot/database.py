import asyncio
import sqlite3

from . import common


class Database:
    def __init__(self, path: str):
        self.path = path

    async def initialize(self) -> None:
        await asyncio.to_thread(self._initialize)

    def _initialize(self) -> None:
        conn = sqlite3.connect(self.path)
        try:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    first_name TEXT,
                    joined_at TEXT NOT NULL,
                    downloads_count INTEGER NOT NULL DEFAULT 0,
                    last_activity TEXT NOT NULL
                )
                """
            )

            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS downloads (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    url TEXT NOT NULL,
                    platform TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
                """
            )

            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_downloads_user_id
                ON downloads(user_id)
                """
            )

            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_downloads_created_at
                ON downloads(created_at)
                """
            )

            conn.commit()
        finally:
            conn.close()

    async def upsert_user(
        self,
        user_id: int,
        username: str | None,
        first_name: str | None,
    ) -> None:
        await asyncio.to_thread(
            self._upsert_user,
            user_id,
            username,
            first_name,
        )

    def _upsert_user(
        self,
        user_id: int,
        username: str | None,
        first_name: str | None,
    ) -> None:
        now = common.utc_now()

        conn = sqlite3.connect(self.path)
        try:
            conn.execute(
                """
                INSERT INTO users (
                    user_id,
                    username,
                    first_name,
                    joined_at,
                    last_activity
                )
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET
                    username = excluded.username,
                    first_name = excluded.first_name,
                    last_activity = excluded.last_activity
                """,
                (
                    user_id,
                    username,
                    first_name,
                    now,
                    now,
                ),
            )
            conn.commit()
        finally:
            conn.close()

    async def add_download(
        self,
        user_id: int,
        url: str,
        platform: str,
        status: str,
    ) -> int:
        return await asyncio.to_thread(
            self._add_download,
            user_id,
            url,
            platform,
            status,
        )

    def _add_download(
        self,
        user_id: int,
        url: str,
        platform: str,
        status: str,
    ) -> int:
        conn = sqlite3.connect(self.path)
        try:
            cursor = conn.execute(
                """
                INSERT INTO downloads (
                    user_id,
                    url,
                    platform,
                    status,
                    created_at
                )
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    user_id,
                    url,
                    platform,
                    status,
                    common.utc_now(),
                ),
            )
            conn.commit()
            return int(cursor.lastrowid)
        finally:
            conn.close()

    async def update_download_status(
        self,
        download_id: int,
        status: str,
    ) -> None:
        await asyncio.to_thread(
            self._update_download_status,
            download_id,
            status,
        )

    def _update_download_status(
        self,
        download_id: int,
        status: str,
    ) -> None:
        conn = sqlite3.connect(self.path)
        try:
            conn.execute(
                """
                UPDATE downloads
                SET status = ?
                WHERE id = ?
                """,
                (status, download_id),
            )
            conn.commit()
        finally:
            conn.close()

    async def increment_downloads(self, user_id: int) -> None:
        await asyncio.to_thread(
            self._increment_downloads,
            user_id,
        )

    def _increment_downloads(self, user_id: int) -> None:
        conn = sqlite3.connect(self.path)
        try:
            conn.execute(
                """
                UPDATE users
                SET downloads_count = downloads_count + 1
                WHERE user_id = ?
                """,
                (user_id,),
            )
            conn.commit()
        finally:
            conn.close()

    async def get_stats(self) -> dict[str, int]:
        return await asyncio.to_thread(self._get_stats)

    def _get_stats(self) -> dict[str, int]:
        today = common.utc_now()[:10]

        conn = sqlite3.connect(self.path)
        try:
            users = conn.execute(
                "SELECT COUNT(*) FROM users"
            ).fetchone()[0]

            downloads = conn.execute(
                "SELECT COUNT(*) FROM downloads"
            ).fetchone()[0]

            today_downloads = conn.execute(
                """
                SELECT COUNT(*)
                FROM downloads
                WHERE substr(created_at, 1, 10) = ?
                AND status = 'completed'
                """,
                (today,),
            ).fetchone()[0]

            tiktok = conn.execute(
                """
                SELECT COUNT(*)
                FROM downloads
                WHERE platform = 'tiktok'
                AND status = 'completed'
                """
            ).fetchone()[0]

            facebook = conn.execute(
                """
                SELECT COUNT(*)
                FROM downloads
                WHERE platform = 'facebook'
                AND status = 'completed'
                """
            ).fetchone()[0]

            instagram = conn.execute(
                """
                SELECT COUNT(*)
                FROM downloads
                WHERE platform = 'instagram'
                AND status = 'completed'
                """
            ).fetchone()[0]

            x_platform = conn.execute(
                """
                SELECT COUNT(*)
                FROM downloads
                WHERE platform = 'x'
                AND status = 'completed'
                """
            ).fetchone()[0]

            failed = conn.execute(
                """
                SELECT COUNT(*)
                FROM downloads
                WHERE status = 'failed'
                """
            ).fetchone()[0]

            return {
                "users": users,
                "downloads": downloads,
                "today": today_downloads,
                "tiktok": tiktok,
                "facebook": facebook,
                "instagram": instagram,
                "x": x_platform,
                "failed": failed,
            }
        finally:
            conn.close()

    async def get_user_ids(self) -> list[int]:
        return await asyncio.to_thread(self._get_user_ids)

    def _get_user_ids(self) -> list[int]:
        conn = sqlite3.connect(self.path)
        try:
            rows = conn.execute(
                "SELECT user_id FROM users"
            ).fetchall()
            return [int(row[0]) for row in rows]
        finally:
            conn.close()


db = Database(common.DATABASE_PATH)
