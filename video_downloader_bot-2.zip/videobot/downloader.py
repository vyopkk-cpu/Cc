import asyncio
import time
import uuid
from contextlib import suppress
from pathlib import Path
from typing import Any

from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from aiogram.types import (
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InputMediaPhoto,
    InputMediaVideo,
    Message,
)

from . import common
from .database import db
from .services import facebook_service, instagram_service, tiktok_service, x_service


async def safe_edit_status(message: Message, text: str) -> None:
    with suppress(TelegramBadRequest, TelegramForbiddenError):
        await message.edit_text(text)


async def safe_delete_message(message: Message) -> None:
    with suppress(TelegramBadRequest, TelegramForbiddenError):
        await message.delete()


async def process_download(
    *,
    user_id: int,
    url: str,
    platform: str,
    status_message: Message,
) -> None:
    start_time = time.monotonic()
    work_dir = common.DOWNLOAD_DIR / uuid.uuid4().hex
    download_id: int | None = None

    try:
        common.ensure_download_dir()
        work_dir.mkdir(parents=True, exist_ok=True)

        download_id = await db.add_download(user_id, url, platform, "waiting")
        await db.update_download_status(download_id, "processing")

        await safe_edit_status(status_message, "جاري التحميل...")

        async with common.download_semaphore:
            await db.update_download_status(download_id, "downloading")

            if platform == "tiktok":
                result = await tiktok_service.download_tiktok(url, work_dir)

            elif platform == "facebook":
                result = await facebook_service.download_facebook(url, work_dir)

            elif platform == "instagram":
                result = await instagram_service.download_instagram(url, work_dir)

            elif platform == "x":
                result = await x_service.download_x(url, work_dir)

            else:
                raise common.UnsupportedPlatformError()

        await db.update_download_status(download_id, "sending")
        await safe_edit_status(status_message, "تم التحميل بنجاح، جاري الإرسال...")

        await send_download_result(
            status_message.bot,
            user_id,
            platform,
            result,
        )

        await db.update_download_status(download_id, "completed")
        await db.increment_downloads(user_id)

        elapsed = time.monotonic() - start_time

        common.logger.info(
            "Download completed | user=%s | platform=%s | "
            "duration=%.2fs | size=%s",
            user_id,
            platform,
            elapsed,
            common.format_size(result.get("size")),
        )

        await safe_delete_message(status_message)

    except common.FileTooLargeError:
        if download_id:
            await db.update_download_status(download_id, "failed")

        common.logger.warning(
            "File too large | user=%s | platform=%s",
            user_id,
            platform,
        )

        await safe_edit_status(
            status_message,
            "حجم الملف أكبر من الحد المسموح به.",
        )

    except common.UnsupportedPlatformError:
        if download_id:
            await db.update_download_status(download_id, "failed")

        await safe_edit_status(status_message, "هذه المنصة غير مدعومة حالياً.")

    except common.ContentNotFoundError:
        if download_id:
            await db.update_download_status(download_id, "failed")

        common.logger.warning(
            "Content not found | user=%s | platform=%s",
            user_id,
            platform,
        )

        # This is a real "gone" case (e.g. an expired Instagram story) —
        # retrying can never help, so the message doesn't suggest it.
        await safe_edit_status(
            status_message,
            "المحتوى غير متاح أو تم حذفه أو انتهت صلاحيته (مثل الستوريات المنتهية).",
        )

    except asyncio.CancelledError:
        if download_id:
            with suppress(Exception):
                await db.update_download_status(download_id, "failed")
        raise

    except Exception:
        if download_id:
            with suppress(Exception):
                await db.update_download_status(download_id, "failed")

        elapsed = time.monotonic() - start_time

        common.logger.exception(
            "Download failed | user=%s | platform=%s | duration=%.2fs",
            user_id,
            platform,
            elapsed,
        )

        await safe_edit_status(
            status_message,
            "تعذر التحميل حالياً، حاول مرة أخرى.",
        )

    finally:
        common.cleanup_path(work_dir)
        common.active_users.pop(user_id, None)
        common.clear_duplicate_request(url)


async def send_download_result(
    bot: Bot,
    user_id: int,
    platform: str,
    result: dict[str, Any],
) -> None:
    result_type = result.get("type")
    title = result.get("title")

    # Styled as: "- @botusername" then the title/description inside a
    # native Telegram quote block (<blockquote>, requires ParseMode.HTML,
    # set on the Bot in main.py). The title is HTML-escaped since it can
    # contain arbitrary characters (<, >, &).
    def _escape_html(text: str) -> str:
        return (
            text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
        )

    handle = f"@{common.bot_username}" if common.bot_username else "Bot"
    caption = f"- {handle}"

    if title:
        safe_title = _escape_html(str(title)[:900])
        caption += f"\n\n<blockquote>{safe_title}</blockquote>"

    if result_type == "album":
        items = result.get("files") or []

        valid_items: list[dict[str, Any]] = []

        for item in items:
            if isinstance(item, dict):
                item_path = item.get("path")
                item_type = item.get("type", "image")
            else:
                # Defensive fallback: a plain Path defaults to "image".
                item_path = item
                item_type = "image"

            if not isinstance(item_path, Path):
                continue

            if not item_path.exists():
                continue

            if item_path.stat().st_size > common.MAX_FILE_SIZE_BYTES:
                continue

            valid_items.append({"path": item_path, "type": item_type})

        if not valid_items:
            raise RuntimeError("No valid album items to send")

        # Telegram media groups only allow 2-10 items per message. Split
        # into batches of 10 if the album is larger; the caption (with
        # the description) goes on the first item of the FIRST batch
        # only — a single message-with-caption experience, not one
        # caption per photo/video.
        batch_size = 10

        for batch_index in range(0, len(valid_items), batch_size):
            batch = valid_items[batch_index: batch_index + batch_size]

            if len(batch) == 1:
                # Telegram rejects a media group with only one item —
                # send it as a normal single message instead.
                only = batch[0]
                media_caption = caption if batch_index == 0 else None

                if only["type"] == "video":
                    await bot.send_video(
                        chat_id=user_id,
                        video=FSInputFile(only["path"]),
                        caption=media_caption,
                        supports_streaming=True,
                    )
                else:
                    await bot.send_photo(
                        chat_id=user_id,
                        photo=FSInputFile(only["path"]),
                        caption=media_caption,
                    )
                continue

            media_group: list[Any] = []

            for position, item in enumerate(batch):
                item_caption = (
                    caption if batch_index == 0 and position == 0 else None
                )

                if item["type"] == "video":
                    media_group.append(
                        InputMediaVideo(
                            media=FSInputFile(item["path"]),
                            caption=item_caption,
                            supports_streaming=True,
                        )
                    )
                else:
                    media_group.append(
                        InputMediaPhoto(
                            media=FSInputFile(item["path"]),
                            caption=item_caption,
                        )
                    )

            await bot.send_media_group(chat_id=user_id, media=media_group)

        audio_path = result.get("audio")

        if isinstance(audio_path, Path) and audio_path.exists():
            if audio_path.stat().st_size <= common.MAX_FILE_SIZE_BYTES:
                await bot.send_audio(
                    chat_id=user_id,
                    audio=FSInputFile(audio_path),
                    title=str(title)[:64] if title else None,
                )

        return

    path = result.get("path")

    if not isinstance(path, Path):
        raise RuntimeError("Invalid downloaded file")

    if not path.exists():
        raise RuntimeError("Downloaded file does not exist")

    size = path.stat().st_size

    if size > common.MAX_FILE_SIZE_BYTES:
        raise common.FileTooLargeError()

    if result_type == "video":
        keyboard = None

        # TikTok videos get HD/normal-quality-alternate and MP3 buttons
        # attached directly to the video message (not a separate message)
        # — the reference tool's interactive HD/MP3 choice, made
        # non-interactive: tapping a button downloads and sends that
        # extra format on demand instead of asking upfront.
        if platform == "tiktok":
            extra = result.get("extra") or {}
            token = common.register_tiktok_media(
                user_id,
                mp3=extra.get("mp3"),
                alt_quality=extra.get("alt_quality"),
                alt_url=extra.get("alt_url"),
            )

            if token:
                buttons: list[InlineKeyboardButton] = []

                if extra.get("alt_url"):
                    label = (
                        "🎬 نسخة HD"
                        if extra.get("alt_quality") == "hd"
                        else "📹 الجودة العادية"
                    )
                    buttons.append(
                        InlineKeyboardButton(
                            text=label,
                            callback_data=f"tk:{token}:alt",
                        )
                    )

                if extra.get("mp3"):
                    buttons.append(
                        InlineKeyboardButton(
                            text="🎵 استخراج الصوت MP3",
                            callback_data=f"tk:{token}:mp3",
                        )
                    )

                if buttons:
                    keyboard = InlineKeyboardMarkup(inline_keyboard=[buttons])

        await bot.send_video(
            chat_id=user_id,
            video=FSInputFile(path),
            caption=caption,
            supports_streaming=True,
            reply_markup=keyboard,
        )
        return

    if result_type == "image":
        await bot.send_photo(
            chat_id=user_id,
            photo=FSInputFile(path),
            caption=caption,
        )
        return

    raise RuntimeError("Unsupported result type")
