"""One class per platform, each with a single public
`download_<platform>(url, work_dir) -> dict` coroutine. Kept in one file
(instead of one file per platform) since each class is short and they
share no state beyond the common HTTP helpers.

Every returned dict has at minimum: "type" ("video" | "image" | "album"),
"title", "size". A "video"/"image" result also has "path" (a Path to the
downloaded file). An "album" result has "files": a list of
{"path": Path, "type": "video" | "image"} dicts instead.
"""

import asyncio
import html
import json
import os
from contextlib import suppress
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urlparse

import aiohttp
from bs4 import BeautifulSoup

from . import common
from .common import download_binary_to_file, http_request_with_retry, logger


# ============================================================
# TIKTOK — via dvtik.com
# ============================================================
#
# Replaces the previous mysocialdownloader.com AJAX integration (which
# started getting blocked/challenged at the network level — "TikTok
# service page unavailable"). Mirrors a confirmed-working reference
# script exactly: an HTML page is scraped (not a clean JSON API), so
# BeautifulSoup does the parsing. The flow matters — a GET to the base
# URL first, THEN the POST — since the site's anti-bot protection
# appears to key off that first request/cookie exchange.
#
# TikTok "photo mode" posts (single OR multi-image) are always parsed as
# an "images" list by dvtik.com — there's no separate single-photo case —
# so they're always returned here as an "album" (downloader.py already
# collapses a 1-item album into a normal single-photo message).

class TikTokService:
    async def download_tiktok(
        self,
        url: str,
        work_dir: Path,
    ) -> dict[str, Any]:
        headers = {
            "Accept": "*/*",
            "Accept-Language": "ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7",
            "Content-Type": "application/json",
            "Origin": common.TIKTOK_BASE_URL.rstrip("/"),
            "Referer": common.TIKTOK_BASE_URL,
            "User-Agent": common.USER_AGENT_TIKTOK,
        }

        # Prime the session exactly like the reference script does: GET
        # the homepage first (sets whatever cookies the anti-bot check
        # needs) before the actual POST.
        priming = await http_request_with_retry(
            "GET",
            common.TIKTOK_BASE_URL,
            headers=headers,
            timeout=aiohttp.ClientTimeout(
                total=common.API_TIMEOUT,
                connect=15,
                sock_read=30,
            ),
        )
        await priming.release()

        payload = {
            "url": url,
            "locale": "en",
            "type": "video",
        }

        response = await http_request_with_retry(
            "POST",
            common.TIKTOK_DOWNLOAD_URL,
            headers=headers,
            json_data=payload,
            timeout=aiohttp.ClientTimeout(
                total=common.API_TIMEOUT,
                connect=15,
                sock_read=120,
            ),
        )

        try:
            if response.status != 200:
                raise RuntimeError(f"TikTok API HTTP {response.status}")

            html_text = await response.text(errors="replace")
        finally:
            await response.release()

        data = self._parse_response(html_text)

        media_headers = {
            "User-Agent": common.USER_AGENT_TIKTOK,
            "Referer": common.TIKTOK_BASE_URL,
            "Accept": "*/*",
        }

        if data["type"] == "album":
            return await self._download_album(data, work_dir, media_headers)

        if data["type"] == "video":
            return await self._download_video(data, work_dir, media_headers)

        raise RuntimeError("Unsupported TikTok content type: unknown")

    @staticmethod
    def _clean_url(raw_url: str) -> str:
        return html.unescape(raw_url).strip()

    @staticmethod
    def _get_extension(url: str, default: str = "jpg") -> str:
        path = url.split("?", 1)[0].lower()

        if ".mp4" in path:
            return "mp4"
        if ".webp" in path:
            return "webp"
        if ".jpeg" in path or ".jpg" in path:
            return "jpg"
        if ".png" in path:
            return "png"
        if "audio_mpeg" in url or ".mp3" in path:
            return "mp3"

        return default

    def _parse_response(self, response_text: str) -> dict[str, Any]:
        soup = BeautifulSoup(response_text, "html.parser")

        result = soup.select_one(".result")

        if not result:
            raise RuntimeError("TikTok result not found")

        title_element = result.select_one(".video-title")
        title = title_element.get_text(" ", strip=True) if title_element else None

        hd_url = None
        normal_url = None
        mp3_url = None

        for button in result.select(".download-container .download-btn"):
            src = button.get("data-src")

            if not src:
                continue

            src = self._clean_url(src)

            label_element = button.select_one(".download-btn__label")
            label = (
                label_element.get_text(" ", strip=True)
                if label_element
                else button.get_text(" ", strip=True)
            )

            if "Without Watermark [HD]" in label:
                hd_url = src
            elif "Without Watermark" in label and "HD" not in label:
                normal_url = src
            elif "Music MP3" in label or "MP3" in label:
                mp3_url = src

        images: list[str] = []

        for slide in soup.select(".slides-details .slide"):
            button = slide.select_one(".slide-download[data-src]")

            if not button:
                continue

            src = button.get("data-src")

            if not src:
                continue

            images.append(self._clean_url(src))

        if images:
            content_type = "album"
        elif hd_url or normal_url:
            content_type = "video"
        else:
            content_type = "unknown"

        return {
            "type": content_type,
            "title": title,
            "hd": hd_url,
            "normal": normal_url,
            "video": hd_url or normal_url,
            "mp3": mp3_url,
            "images": images,
        }

    # TikTok's CDN sometimes 403s an otherwise-valid signed URL depending
    # on the Referer sent — and which Referer works isn't something I can
    # verify without hitting the live CDN, so this tries a few plausible
    # values in order and uses whichever succeeds first, instead of
    # failing outright on the first attempt like before.
    _REFERER_FALLBACKS = ("https://dvtik.com/", None, "https://www.tiktok.com/")

    async def _download_media_with_fallback(
        self,
        url: str,
        target: Path,
        base_headers: dict[str, str],
    ) -> Path:
        last_exc: Optional[Exception] = None

        for referer in self._REFERER_FALLBACKS:
            headers = {k: v for k, v in base_headers.items() if k != "Referer"}

            if referer:
                headers["Referer"] = referer

            try:
                return await download_binary_to_file(url, target, headers=headers)
            except Exception as exc:
                last_exc = exc
                logger.warning(
                    "TikTok media download failed (referer=%s): %s",
                    referer,
                    exc,
                )
                continue

        raise last_exc or RuntimeError("TikTok media download failed")

    async def download_extra_media(self, url: str, target: Path) -> Path:
        """Public entry point for downloading a bonus asset (the
        alternate-quality video or the MP3 audio) after the user taps one
        of the buttons on the original video message. Reuses the same
        Referer-fallback logic as the main download.
        """
        media_headers = {
            "User-Agent": common.USER_AGENT_TIKTOK,
            "Referer": common.TIKTOK_BASE_URL,
            "Accept": "*/*",
        }

        return await self._download_media_with_fallback(url, target, media_headers)

    async def _download_video(
        self,
        data: dict[str, Any],
        work_dir: Path,
        media_headers: dict[str, str],
    ) -> dict[str, Any]:
        video_url = data.get("video")

        if not video_url:
            raise RuntimeError("TikTok video URL not found")

        path = await self._download_media_with_fallback(
            video_url,
            work_dir / "tiktok_video.mp4",
            media_headers,
        )

        sent_quality = "hd" if video_url == data.get("hd") else "normal"

        # The OTHER quality (whichever wasn't auto-sent) and the MP3 audio
        # track are offered as buttons on the video message instead of
        # being downloaded automatically — downloader.py builds the
        # keyboard from this "extra" dict and only fetches them on demand
        # if the user taps a button, matching the reference tool's
        # optional HD/MP3 choice.
        extra: dict[str, Any] = {"mp3": data.get("mp3")}

        if sent_quality == "hd" and data.get("normal"):
            extra["alt_quality"] = "normal"
            extra["alt_url"] = data.get("normal")
        elif sent_quality == "normal" and data.get("hd"):
            extra["alt_quality"] = "hd"
            extra["alt_url"] = data.get("hd")

        return {
            "type": "video",
            "path": path,
            "title": data.get("title"),
            "size": path.stat().st_size,
            "extra": extra,
        }

    async def _download_album(
        self,
        data: dict[str, Any],
        work_dir: Path,
        media_headers: dict[str, str],
    ) -> dict[str, Any]:
        images = data.get("images") or []

        if not images:
            raise RuntimeError("TikTok album is empty")

        album_dir = work_dir / "tiktok_album"
        album_dir.mkdir(parents=True, exist_ok=True)

        files: list[dict[str, Any]] = []

        for index, image_url in enumerate(images, 1):
            ext = self._get_extension(image_url, "jpg")
            target = album_dir / f"{index:02d}.{ext}"

            try:
                await self._download_media_with_fallback(
                    image_url,
                    target,
                    media_headers,
                )
                files.append({"path": target, "type": "image"})
            except Exception:
                logger.exception(
                    "Failed to download TikTok album image %s", index
                )

        if not files:
            raise RuntimeError("No TikTok album images were downloaded")

        # Unlike the video's HD/MP3 (offered via buttons), the album's
        # audio track is downloaded automatically and sent alongside the
        # images — matching the reference tool's download_album(), which
        # never asks and just includes the mp3 whenever one exists.
        audio_path: Optional[Path] = None
        mp3_url = data.get("mp3")

        if mp3_url:
            audio_target = album_dir / "audio.mp3"
            try:
                audio_path = await self._download_media_with_fallback(
                    mp3_url,
                    audio_target,
                    media_headers,
                )
            except Exception:
                logger.exception("Failed to download TikTok album audio")

        return {
            "type": "album",
            "files": files,
            "title": data.get("title"),
            "audio": audio_path,
            "size": sum(
                item["path"].stat().st_size
                for item in files
                if item["path"].exists()
            ),
        }


# ============================================================
# FACEBOOK — via socialecho.net
# ============================================================

class FacebookService:
    async def download_facebook(
        self,
        url: str,
        work_dir: Path,
    ) -> dict[str, Any]:
        headers = {
            "Accept": "*/*",
            "Content-Type": "application/json",
            "Origin": "https://www.socialecho.net",
            "Referer": (
                "https://www.socialecho.net/"
                "free-tools/photo-video-downloader/"
            ),
            "User-Agent": common.USER_AGENT_FACEBOOK,
        }

        response = await http_request_with_retry(
            "POST",
            common.FACEBOOK_API_URL,
            headers=headers,
            json_data={"url": url},
            timeout=aiohttp.ClientTimeout(
                total=common.API_TIMEOUT,
                connect=15,
                sock_read=60,
            ),
        )

        try:
            if response.status != 200:
                body = await response.text(errors="replace")
                logger.warning(
                    "Facebook API HTTP %s: %s",
                    response.status,
                    body[:500],
                )
                raise RuntimeError(f"Facebook API HTTP {response.status}")

            try:
                result = await response.json(content_type=None)
            except (ValueError, json.JSONDecodeError):
                raise RuntimeError("Facebook API returned invalid JSON")
        finally:
            await response.release()

        if not isinstance(result, dict):
            raise RuntimeError("Invalid Facebook API response")

        medias = result.get("medias")

        if not isinstance(medias, list) or not medias:
            raise RuntimeError("Facebook video not found")

        video = next(
            (
                media
                for media in medias
                if isinstance(media, dict)
                and media.get("type") == "video"
                and media.get("ext") == "mp4"
                and media.get("url")
            ),
            None,
        )

        if not video:
            raise RuntimeError("Facebook MP4 video URL not found")

        video_url = video["url"]

        video_headers = {
            "User-Agent": headers["User-Agent"],
            "Referer": "https://www.facebook.com/",
        }

        target = work_dir / "facebook_reel.mp4"

        path = await download_binary_to_file(
            video_url,
            target,
            headers=video_headers,
        )

        return {
            "type": "video",
            "path": path,
            "title": result.get("title"),
            "duration": video.get("duration"),
            "size": path.stat().st_size,
        }


# ============================================================
# INSTAGRAM — via savefromins.com
# ============================================================
#
# Resolves posts/reels/albums. A single post can resolve to one or many
# media items (a "carousel" album can mix photos and videos); every item
# is downloaded, and downloader.send_download_result decides whether to
# send it as one video/photo message (single item) or as one grouped
# album message (multiple items).
#
# FIX: the response shape is: {"status_code": "success", "data": {
# "title"/"id", "media": [ {"type": ..., "resources": [ {"download_url",
# "original_format"/"format", "type"}, ... ] }, ... ] } } — the earlier
# implementation incorrectly assumed a flat "resources" list directly
# under "data". Confirmed against a working reference script. A
# top-level "status_code" != "success" also means failure even when the
# HTTP status itself is 200.

class InstagramService:
    _IMAGE_EXTS = {"jpg", "jpeg", "png", "webp", "gif"}
    _VIDEO_EXTS = {"mp4", "mov", "m4v", "webm"}

    @classmethod
    def _get_extension(cls, resource: dict) -> Optional[str]:
        ext = str(
            resource.get("original_format") or resource.get("format") or ""
        ).lower().strip()

        if ext == "jpeg":
            ext = "jpg"

        if ext in cls._IMAGE_EXTS or ext in cls._VIDEO_EXTS:
            return ext

        return None

    @classmethod
    def _get_media_type(cls, media: dict, resource: dict) -> str:
        raw_type = str(media.get("type") or resource.get("type") or "").lower()

        if raw_type in {"picture", "image", "photo"}:
            return "image"

        if raw_type in {"video", "movie"}:
            return "video"

        ext = cls._get_extension(resource)

        if ext in cls._IMAGE_EXTS:
            return "image"

        if ext in cls._VIDEO_EXTS:
            return "video"

        return "unknown"

    async def download_instagram(
        self,
        url: str,
        work_dir: Path,
    ) -> dict[str, Any]:
        headers = {
            "Accept": "*/*",
            "Accept-Language": "ar,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
            "Content-Type": "application/x-www-form-urlencoded",
            "Origin": "https://savefromins.com",
            "Referer": "https://savefromins.com/",
            "User-Agent": common.USER_AGENT_INSTAGRAM,
        }

        form_data = {
            "auth": common.INSTAGRAM_API_AUTH,
            "domain": common.INSTAGRAM_API_DOMAIN,
            "origin": "source",
            "link": url,
        }

        response = await http_request_with_retry(
            "POST",
            common.INSTAGRAM_API_URL,
            headers=headers,
            data=form_data,
            timeout=aiohttp.ClientTimeout(
                total=common.API_TIMEOUT,
                connect=15,
                sock_read=60,
            ),
        )

        try:
            if response.status != 200:
                body = await response.text(errors="replace")
                logger.warning(
                    "Instagram API HTTP %s: %s",
                    response.status,
                    body[:500],
                )
                raise RuntimeError(f"Instagram API HTTP {response.status}")

            try:
                result = await response.json(content_type=None)
            except (ValueError, json.JSONDecodeError):
                raise RuntimeError("Instagram API returned invalid JSON")
        finally:
            await response.release()

        if not isinstance(result, dict):
            raise RuntimeError("Invalid Instagram API response")

        if result.get("status_code") != "success":
            raw_msg = json.dumps(result, ensure_ascii=False)
            logger.warning("Instagram API non-success response: %s", raw_msg[:500])

            # FIX: distinguish "content genuinely gone" (e.g. an expired
            # story — retrying can never help) from a generic API/parse
            # failure (worth telling the user to just try again).
            if "content_not_found" in raw_msg or "MediaNotFound" in raw_msg:
                raise common.ContentNotFoundError(
                    "Instagram content not found or unavailable"
                )

            raise RuntimeError("Instagram API rejected the URL")

        payload = result.get("data") or {}

        if not isinstance(payload, dict):
            raise RuntimeError("Invalid Instagram API data")

        media_list = payload.get("media")

        if not isinstance(media_list, list) or not media_list:
            # Fallback for a flatter response shape: wrap a top-level
            # "resources" list as a single synthetic media entry.
            resources = payload.get("resources")

            if isinstance(resources, list) and resources:
                first = resources[0] if isinstance(resources[0], dict) else {}
                media_list = [{"type": first.get("type"), "resources": resources}]
            else:
                media_list = []

        if not media_list:
            raise RuntimeError("Instagram media not found")

        valid_media: list[tuple[dict, dict]] = []

        for media in media_list:
            if not isinstance(media, dict):
                continue

            resources = media.get("resources")

            if not isinstance(resources, list):
                continue

            resource = next(
                (
                    r for r in resources
                    if isinstance(r, dict) and r.get("download_url")
                ),
                None,
            )

            if resource:
                valid_media.append((media, resource))

        if not valid_media:
            raise RuntimeError("No Instagram download URL found")

        # FIX: only use a REAL title/caption from the API. The previous
        # "or payload.get('id')" fallback meant content with no caption
        # (most notably stories, which have no title field at all) ended
        # up showing a meaningless raw numeric id as the caption — never
        # what was intended. If there's no real title, no caption is
        # shown at all (handled by downloader.send_download_result, which
        # only adds the blockquote when title is truthy).
        title = payload.get("title")

        files: list[dict[str, Any]] = []
        index = 0

        for media, resource in valid_media:
            download_url = resource.get("download_url")
            media_type = self._get_media_type(media, resource)
            ext = self._get_extension(resource)

            if not ext:
                with suppress(Exception):
                    url_path = urlparse(download_url).path
                    url_ext = os.path.splitext(url_path)[1].lower().lstrip(".")
                    if url_ext:
                        ext = url_ext

            if media_type == "unknown":
                media_type = "image" if ext in self._IMAGE_EXTS else "video"

            if not ext:
                ext = "mp4" if media_type == "video" else "jpg"

            index += 1
            target = work_dir / f"instagram_{index:02d}.{ext}"

            try:
                path = await download_binary_to_file(
                    download_url,
                    target,
                    headers={
                        "User-Agent": common.USER_AGENT_INSTAGRAM,
                        "Referer": "https://www.instagram.com/",
                    },
                )
                files.append({"path": path, "type": media_type})
            except Exception:
                logger.exception(
                    "Failed to download Instagram item %s", index
                )

        if not files:
            raise RuntimeError("No Instagram media was downloaded")

        if len(files) == 1:
            only = files[0]
            path = only["path"]

            return {
                "type": only["type"],
                "path": path,
                "title": title,
                "size": path.stat().st_size,
            }

        return {
            "type": "album",
            "files": files,
            "title": title,
            "size": sum(
                item["path"].stat().st_size
                for item in files
                if item["path"].exists()
            ),
        }


# ============================================================
# X (TWITTER) — via x-downloader.com
# ============================================================
#
# Downloads use HTTP Range requests so an interrupted download can resume
# from where it left off instead of restarting from scratch.

class XService:
    async def download_x(
        self,
        url: str,
        work_dir: Path,
    ) -> dict[str, Any]:
        headers = {
            "Accept": "*/*",
            "Content-Type": "application/json",
            "Origin": "https://x-downloader.com",
            "Referer": "https://x-downloader.com/",
            "User-Agent": "Mozilla/5.0",
        }

        response = await http_request_with_retry(
            "POST",
            common.X_DOWNLOADER_REQUEST_URL,
            headers=headers,
            json_data={"url": url, "type": ".mp4"},
            timeout=aiohttp.ClientTimeout(
                total=common.API_TIMEOUT,
                connect=15,
                sock_read=60,
            ),
        )

        try:
            if response.status != 200:
                body = await response.text(errors="replace")
                logger.warning(
                    "X API HTTP %s: %s",
                    response.status,
                    body[:500],
                )
                raise RuntimeError(f"X API HTTP {response.status}")

            try:
                result = await response.json(content_type=None)
            except (ValueError, json.JSONDecodeError):
                raise RuntimeError("X API returned invalid JSON")
        finally:
            await response.release()

        if not isinstance(result, dict):
            raise RuntimeError("Invalid X API response")

        filename_field = result.get("filename")

        if not filename_field:
            logger.warning(
                "X API response missing filename: %s",
                json.dumps(result, ensure_ascii=False)[:500],
            )
            raise RuntimeError("X video not found")

        download_url = common.X_DOWNLOADER_BASE_URL + str(filename_field)
        # FIX: X videos are intentionally excluded from the caption/
        # description list — "titleFilename" is just a generated filename
        # (often the literal word "video"), not a real description, so
        # showing it as a caption is pure noise. Always None here; the
        # message will just be "- @botusername" with no quote block.
        title = None
        target = work_dir / "x_video.mp4"

        path = await self._download_with_resume(
            download_url,
            target,
            headers={"User-Agent": headers["User-Agent"]},
        )

        return {
            "type": "video",
            "path": path,
            "title": title,
            "size": path.stat().st_size,
        }

    async def _download_with_resume(
        self,
        url: str,
        target: Path,
        *,
        headers: dict[str, str],
        max_attempts: int = 4,
    ) -> Path:
        target.parent.mkdir(parents=True, exist_ok=True)

        total_size: Optional[int] = None

        with suppress(Exception):
            session = await common.get_http_session()
            async with session.head(
                url,
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=30),
                allow_redirects=True,
            ) as head_response:
                content_length = head_response.headers.get("Content-Length")
                if content_length:
                    total_size = int(content_length)

        if total_size and total_size > common.MAX_FILE_SIZE_BYTES:
            raise common.FileTooLargeError()

        position = target.stat().st_size if target.exists() else 0

        try:
            for attempt in range(max_attempts):
                range_headers = {
                    **headers,
                    "Accept": "*/*",
                    "Range": f"bytes={position}-",
                }

                session = await common.get_http_session()

                try:
                    async with session.get(
                        url,
                        headers=range_headers,
                        timeout=aiohttp.ClientTimeout(
                            total=common.DOWNLOAD_TIMEOUT,
                            connect=30,
                            sock_read=60,
                        ),
                    ) as response:
                        if response.status not in (200, 206):
                            raise RuntimeError(
                                f"X media HTTP {response.status}"
                            )

                        mode = "ab" if position else "wb"

                        with target.open(mode) as file:
                            async for chunk in response.content.iter_chunked(
                                1024 * 1024
                            ):
                                if not chunk:
                                    continue

                                position += len(chunk)

                                if position > common.MAX_FILE_SIZE_BYTES:
                                    raise common.FileTooLargeError()

                                file.write(chunk)

                        if total_size and position >= total_size:
                            return target

                        if response.status == 200:
                            # Server sent the whole file in one go with no
                            # Content-Length to confirm against — done.
                            return target

                except common.FileTooLargeError:
                    raise
                except (aiohttp.ClientError, asyncio.TimeoutError):
                    if attempt >= max_attempts - 1:
                        raise
                    await asyncio.sleep(2)
                    continue

            return target
        except Exception:
            common.cleanup_path(target)
            raise


tiktok_service = TikTokService()
facebook_service = FacebookService()
instagram_service = InstagramService()
x_service = XService()
