import asyncio
import uuid
from contextlib import suppress
from pathlib import Path

from aiogram import Dispatcher, F
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, FSInputFile, Message

from . import common
from .database import db
from .downloader import process_download
from .services import tiktok_service

SUPPORTED_PLATFORMS_TEXT = (
    "المنصات المدعومة:\n"
    "• TikTok\n"
    "• Facebook\n"
    "• Instagram (منشورات، ريلز، ألبومات)\n"
    "• X (Twitter)"
)


class BroadcastState(StatesGroup):
    waiting_message = State()


dp = Dispatcher()


@dp.message(CommandStart())
async def start_handler(message: Message) -> None:
    user = message.from_user

    if not user:
        return

    await db.upsert_user(user.id, user.username, user.first_name)

    await message.answer(
        "أهلاً بك في بوت تحميل الفيديوهات.\n\n"
        "أرسل رابط الفيديو مباشرة وسأقوم بتحميله وإرساله لك.\n\n"
        f"{SUPPORTED_PLATFORMS_TEXT}"
    )


@dp.message(Command("admin"))
async def admin_handler(message: Message) -> None:
    user = message.from_user

    if not user or not common.is_admin(user.id):
        return

    await message.answer(
        "لوحة الإدارة\n\n"
        "/stats - إحصائيات البوت\n"
        "/broadcast - إرسال رسالة لجميع المستخدمين"
    )


@dp.message(Command("stats"))
async def stats_handler(message: Message) -> None:
    user = message.from_user

    if not user or not common.is_admin(user.id):
        return

    stats = await db.get_stats()

    await message.answer(
        "إحصائيات البوت\n\n"
        f"المستخدمون: {stats['users']}\n"
        f"إجمالي عمليات التحميل: {stats['downloads']}\n"
        f"تحميلات اليوم: {stats['today']}\n\n"
        f"TikTok: {stats['tiktok']}\n"
        f"Facebook: {stats['facebook']}\n"
        f"Instagram: {stats['instagram']}\n"
        f"X: {stats['x']}\n\n"
        f"العمليات الفاشلة: {stats['failed']}"
    )


@dp.message(Command("broadcast"))
async def broadcast_handler(message: Message, state: FSMContext) -> None:
    user = message.from_user

    if not user or not common.is_admin(user.id):
        return

    await state.set_state(BroadcastState.waiting_message)

    await message.answer(
        "أرسل الآن الرسالة التي تريد إرسالها لجميع المستخدمين."
    )


@dp.message(BroadcastState.waiting_message)
async def broadcast_message_handler(message: Message, state: FSMContext) -> None:
    user = message.from_user

    if not user or not common.is_admin(user.id):
        await state.clear()
        return

    await state.clear()

    users = await db.get_user_ids()
    success = 0
    failed = 0

    await message.answer(f"بدأ الإرسال إلى {len(users)} مستخدم.")

    for user_id in users:
        try:
            await message.bot.copy_message(
                chat_id=user_id,
                from_chat_id=message.chat.id,
                message_id=message.message_id,
            )
            success += 1
        except (TelegramForbiddenError, TelegramBadRequest):
            failed += 1
        except Exception:
            failed += 1
            common.logger.exception("Broadcast error | user=%s", user_id)

        await asyncio.sleep(0.05)

    await message.answer(
        "اكتمل الإرسال.\n\n"
        f"نجح: {success}\n"
        f"فشل: {failed}"
    )


@dp.callback_query(F.data.startswith("tk:"))
async def tiktok_extra_callback(callback: CallbackQuery) -> None:
    """Handles the "🎬 HD / normal quality" and "🎵 MP3" buttons attached
    to a TikTok video message. callback_data format: "tk:<token>:<kind>"
    where kind is "alt" (alternate-quality video) or "mp3".
    """
    data = callback.data or ""
    parts = data.split(":")

    if len(parts) != 3:
        await callback.answer()
        return

    _, token, kind = parts

    entry = common.consume_tiktok_media(token)

    if not entry or not callback.from_user or entry.get("user_id") != callback.from_user.id:
        await callback.answer(
            "انتهت صلاحية هذا الخيار، أعد إرسال الرابط من جديد.",
            show_alert=True,
        )
        return

    media_url = entry.get("mp3") if kind == "mp3" else entry.get("alt_url")

    if not media_url:
        await callback.answer("غير متوفر.", show_alert=True)
        return

    await callback.answer("جاري التحميل...")

    work_dir = common.DOWNLOAD_DIR / uuid.uuid4().hex
    work_dir.mkdir(parents=True, exist_ok=True)

    try:
        extension = "mp3" if kind == "mp3" else "mp4"
        target = work_dir / f"tiktok_extra.{extension}"

        path = await tiktok_service.download_extra_media(media_url, target)

        if path.stat().st_size > common.MAX_FILE_SIZE_BYTES:
            if callback.message:
                await callback.message.answer("حجم الملف أكبر من الحد المسموح به.")
            return

        chat_id = callback.from_user.id

        if kind == "mp3":
            await callback.bot.send_audio(
                chat_id=chat_id,
                audio=FSInputFile(path),
            )
        else:
            await callback.bot.send_video(
                chat_id=chat_id,
                video=FSInputFile(path),
                supports_streaming=True,
            )
    except Exception:
        common.logger.exception(
            "Failed to send TikTok extra media | token=%s | kind=%s",
            token,
            kind,
        )
        with suppress(Exception):
            if callback.message:
                await callback.message.answer("تعذر التحميل حالياً، حاول مرة أخرى.")
    finally:
        common.cleanup_path(work_dir)


@dp.message(F.text)
async def url_handler(message: Message) -> None:
    user = message.from_user

    if not user:
        return

    await db.upsert_user(user.id, user.username, user.first_name)

    url = common.normalize_url(message.text or "")

    if not url:
        await message.answer("الرابط فارغ.")
        return

    if not common.is_valid_url(url):
        await message.answer("الرابط غير صالح أو غير مدعوم.")
        return

    platform = common.detect_platform(url)

    if not platform:
        await message.answer(
            f"هذه المنصة غير مدعومة حالياً.\n\n{SUPPORTED_PLATFORMS_TEXT}"
        )
        return

    if not common.user_rate_allowed(user.id):
        await message.answer(
            "لقد تجاوزت الحد المسموح من الطلبات، حاول بعد قليل."
        )
        return

    if user.id in common.active_users:
        await message.answer(
            "لديك عملية تحميل قيد التنفيذ، انتظر حتى تكتمل."
        )
        return

    if common.is_duplicate_request(url, user.id):
        await message.answer(
            "تم استلام هذا الرابط مؤخراً، انتظر قليلاً قبل إعادة الطلب."
        )
        return

    if common.download_semaphore.locked():
        await message.answer("السيرفر مشغول حالياً، حاول بعد قليل.")
        return

    status_message = await message.answer("جاري التحميل...")

    task = asyncio.create_task(
        process_download(
            user_id=user.id,
            url=url,
            platform=platform,
            status_message=status_message,
        )
    )

    common.active_users[user.id] = task
