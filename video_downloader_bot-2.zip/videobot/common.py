"""Everything shared across the bot that isn't a Telegram handler, the
database, or a platform-specific download service: configuration
constants, logging setup, in-memory shared state, exceptions, small pure
helper functions, and the retrying aiohttp client.

Merged into one file (instead of separate config/logging/state/
exceptions/utils/http_client modules) to keep the file count down, since
none of these pieces are large or complex enough on their own to justify
a dedicated file.
"""

import asyncio
import hashlib
import logging
import re
import shutil
import time
import uuid
from collections import defaultdict, deque
from contextlib import suppress
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urlparse

import aiohttp

# ============================================================
# CONFIGURATION
# ============================================================
#
# SECURITY NOTE: this token was pasted into a chat at some point, so
# treat it as already exposed — regenerate it with @BotFather (/revoke)
# and put the NEW token below before running this in production.
BOT_TOKEN = "8903513779:AAEThkIKfYw010DbccSR7M0BRiZ8QPQw6WI"

ADMIN_IDS = {
    8404320324,
}

# TikTok — via dvtik.com (replaces the previous mysocialdownloader.com
# integration, which was being blocked/challenged at the network level).
TIKTOK_BASE_URL = "https://dvtik.com/"
TIKTOK_DOWNLOAD_URL = "https://dvtik.com/download"
USER_AGENT_TIKTOK = (
    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36"
)

# Facebook — via socialecho.net. The working endpoint is "/api/resolve/",
# NOT "/api/facebook". NOTE: SocialEcho's public FAQ states its free tier
# only allows 3 link resolves per day (likely per IP) — I can't verify
# from here whether that's per API key, per IP, or something else; if
# this bot serves more than ~3 downloads/day total, verify with
# SocialEcho directly.
SOCIALECHO_API_URL = "https://www.socialecho.net/api/resolve/"
FACEBOOK_API_URL = SOCIALECHO_API_URL  # kept as an alias, same endpoint

# This must be the EXACT user-agent used for both the /api/resolve/ call
# and the follow-up media download — the resolver hands back a signed URL
# tied to the requesting UA, so a mismatch (or a desktop UA) between the
# two requests causes the media host to answer 403 even with the correct
# Referer. Confirmed-working value.
USER_AGENT_FACEBOOK = (
    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36"
)

# Instagram — via savefromins.com
INSTAGRAM_API_URL = "https://api.savefromins.com/api/contentsite_api/media/parse"
# NOTE: this "auth" value looks like an app key that may be
# time-stamped/rotated by savefromins.com without notice (it starts with
# a date-like prefix). If Instagram downloads start failing with an auth
# error, this is the first thing to check/update.
INSTAGRAM_API_AUTH = "20250901majwlqo"
INSTAGRAM_API_DOMAIN = "api-ak.savefromins.com"
USER_AGENT_INSTAGRAM = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0"
)

# X (Twitter) — via x-downloader.com
X_DOWNLOADER_REQUEST_URL = "https://api.x-downloader.com/request"
X_DOWNLOADER_BASE_URL = "https://api.x-downloader.com/"

# Storage
DOWNLOAD_DIR = Path("./downloads")
DATABASE_PATH = "./bot.db"

# Limits
MAX_FILE_SIZE_MB = 49
MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024

MAX_CONCURRENT_DOWNLOADS = 3
API_TIMEOUT = 120
DOWNLOAD_TIMEOUT = 300
RETRY_COUNT = 2

USER_RATE_LIMIT_COUNT = 5
USER_RATE_LIMIT_WINDOW = 60

DUPLICATE_WINDOW = 120
MAX_URL_LENGTH = 2000

# How long a TikTok video's alternate-quality/MP3 buttons stay valid
# before the cached URLs are dropped and the buttons report "expired".
TIKTOK_MEDIA_CACHE_TTL = 600


# ============================================================
# LOGGING
# ============================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)

logger = logging.getLogger("video_downloader_bot")


# ============================================================
# EXCEPTIONS
# ============================================================

class FileTooLargeError(Exception):
    pass


class UnsupportedPlatformError(Exception):
    pass


class ContentNotFoundError(Exception):
    """Raised when the source content itself is gone/unavailable (e.g. an
    expired Instagram story) — distinct from a generic API/network
    failure, so the user gets an accurate message instead of "try again"
    for something retrying can never fix.
    """
    pass


# ============================================================
# SHARED IN-MEMORY STATE
# ============================================================
#
# Mutated via module-qualified access elsewhere (e.g.
# `common.http_session = ...`), never rebound through a plain imported
# name, so changes are visible across every module that imports `common`.

download_semaphore = asyncio.Semaphore(MAX_CONCURRENT_DOWNLOADS)

user_rate_history: dict[int, deque[float]] = defaultdict(deque)
active_users: dict[int, asyncio.Task] = {}

# Maps a hash of the URL -> (monotonic timestamp, user_id) used to
# de-duplicate rapid repeat requests for the same link.
recent_requests: dict[str, tuple[float, int]] = {}

http_session: Optional[aiohttp.ClientSession] = None

# Cached at startup (see main.on_startup) so downloader.send_download_result
# can format the "- @botusername" line without an extra API call per
# message.
bot_username: Optional[str] = None

# Maps a short random token (used in inline button callback_data, which
# has a strict size limit) -> {"user_id", "mp3", "alt_quality", "alt_url",
# "timestamp"} for a just-downloaded TikTok video's alternate-quality/MP3
# options. Populated in downloader.py right before the video is sent with
# its inline keyboard, consumed in handlers.py when a button is tapped.
tiktok_media_cache: dict[str, dict[str, Any]] = {}


# ============================================================
# HELPERS
# ============================================================

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def format_size(size: Optional[int]) -> str:
    # Only None is "unknown" — a legitimate 0-byte file should say "0 B".
    if size is None:
        return "غير معروف"

    units = ["B", "KB", "MB", "GB"]
    value = float(size)

    for unit in units:
        if value < 1024:
            return f"{value:.2f} {unit}"
        value /= 1024

    return f"{value:.2f} TB"


def format_duration(seconds: Optional[float]) -> str:
    if seconds is None:
        return "غير معروف"

    try:
        seconds = int(seconds)
    except (TypeError, ValueError):
        return "غير معروف"

    if seconds < 60:
        return f"{seconds} ثانية"

    minutes, sec = divmod(seconds, 60)

    if minutes < 60:
        return f"{minutes} دقيقة و{sec} ثانية"

    hours, minutes = divmod(minutes, 60)
    return f"{hours} ساعة و{minutes} دقيقة"


def normalize_url(url: str) -> str:
    return url.strip()


def is_valid_url(url: str) -> bool:
    if len(url) > MAX_URL_LENGTH:
        return False

    try:
        parsed = urlparse(url)

        if parsed.scheme.lower() not in {"http", "https"}:
            return False

        if not parsed.netloc:
            return False

        if " " in url:
            return False

        return True
    except Exception:
        return False


def detect_platform(url: str) -> Optional[str]:
    try:
        hostname = (urlparse(url).hostname or "").lower()
    except Exception:
        return None

    hostname = hostname.removeprefix("www.")

    if hostname == "tiktok.com" or hostname.endswith(".tiktok.com"):
        return "tiktok"

    if hostname == "vm.tiktok.com" or hostname == "vt.tiktok.com":
        return "tiktok"

    if hostname == "facebook.com" or hostname.endswith(".facebook.com"):
        return "facebook"

    if hostname == "fb.watch":
        return "facebook"

    if hostname == "instagram.com" or hostname.endswith(".instagram.com"):
        return "instagram"

    if hostname == "instagr.am":
        return "instagram"

    if hostname == "x.com" or hostname.endswith(".x.com"):
        return "x"

    if hostname == "twitter.com" or hostname.endswith(".twitter.com"):
        return "x"

    return None


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


def user_rate_allowed(user_id: int) -> bool:
    now = time.monotonic()
    history = user_rate_history[user_id]

    while history and now - history[0] > USER_RATE_LIMIT_WINDOW:
        history.popleft()

    if len(history) >= USER_RATE_LIMIT_COUNT:
        return False

    history.append(now)
    return True


def request_key(url: str) -> str:
    return hashlib.sha256(url.encode("utf-8")).hexdigest()


def cleanup_expired_memory() -> None:
    now = time.monotonic()

    for key, (timestamp, _) in list(recent_requests.items()):
        if now - timestamp > DUPLICATE_WINDOW:
            recent_requests.pop(key, None)


def is_duplicate_request(url: str, user_id: int) -> bool:
    cleanup_expired_memory()

    key = request_key(url)
    item = recent_requests.get(key)

    if not item:
        recent_requests[key] = (time.monotonic(), user_id)
        return False

    timestamp, _ = item

    if time.monotonic() - timestamp <= DUPLICATE_WINDOW:
        return True

    recent_requests[key] = (time.monotonic(), user_id)
    return False


def clear_duplicate_request(url: str) -> None:
    """Release the dedup lock for a URL once its download finishes.

    Otherwise a failed/completed download would stay "locked" for the
    full DUPLICATE_WINDOW, so a user whose download failed instantly
    couldn't retry the same link for up to 2 minutes.
    """
    recent_requests.pop(request_key(url), None)


def register_tiktok_media(user_id: int, mp3: Optional[str], alt_quality: Optional[str], alt_url: Optional[str]) -> Optional[str]:
    """Store a TikTok video's alternate-quality/MP3 URLs under a short
    random token for later lookup from a button callback. Returns None
    (no token, no buttons) if there's nothing to offer.
    """
    if not mp3 and not alt_url:
        return None

    token = uuid.uuid4().hex[:12]

    tiktok_media_cache[token] = {
        "user_id": user_id,
        "mp3": mp3,
        "alt_quality": alt_quality,
        "alt_url": alt_url,
        "timestamp": time.monotonic(),
    }

    _cleanup_expired_tiktok_media()

    return token


def consume_tiktok_media(token: str) -> Optional[dict[str, Any]]:
    """Look up a token's stored URLs without expiring it — a single video
    message may have two buttons (alt quality AND mp3), so tapping one
    must not invalidate the other."""
    _cleanup_expired_tiktok_media()

    entry = tiktok_media_cache.get(token)

    return dict(entry) if entry else None


def _cleanup_expired_tiktok_media() -> None:
    now = time.monotonic()

    for token, entry in list(tiktok_media_cache.items()):
        if now - entry.get("timestamp", 0) > TIKTOK_MEDIA_CACHE_TTL:
            tiktok_media_cache.pop(token, None)


def safe_filename(name: str, fallback: str = "video") -> str:
    name = re.sub(r"[^\w\-. ]+", "_", name, flags=re.UNICODE)
    name = re.sub(r"\s+", " ", name).strip()
    name = name[:100].strip(" .")

    return name or fallback


def ensure_download_dir() -> None:
    DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)


def cleanup_path(path: Optional[Path]) -> None:
    if not path:
        return

    try:
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
        elif path.exists():
            path.unlink(missing_ok=True)
    except Exception:
        logger.exception("Failed to clean path: %s", path)


# ============================================================
# HTTP CLIENT
# ============================================================

async def get_http_session() -> aiohttp.ClientSession:
    global http_session

    if http_session is None or http_session.closed:
        timeout = aiohttp.ClientTimeout(
            total=API_TIMEOUT,
            connect=15,
            sock_read=API_TIMEOUT,
        )

        connector = aiohttp.TCPConnector(
            limit=30,
            ttl_dns_cache=300,
        )

        http_session = aiohttp.ClientSession(
            timeout=timeout,
            connector=connector,
        )

    return http_session


async def close_http_session() -> None:
    global http_session

    if http_session and not http_session.closed:
        await http_session.close()

    http_session = None


async def http_request_with_retry(
    method: str,
    url: str,
    *,
    headers: Optional[dict[str, str]] = None,
    data: Any = None,
    json_data: Any = None,
    timeout: Optional[aiohttp.ClientTimeout] = None,
) -> aiohttp.ClientResponse:
    session = await get_http_session()

    last_error: Optional[Exception] = None

    for attempt in range(RETRY_COUNT + 1):
        try:
            request_timeout = timeout or aiohttp.ClientTimeout(
                total=API_TIMEOUT,
                connect=15,
                sock_read=API_TIMEOUT,
            )

            response = await session.request(
                method,
                url,
                headers=headers,
                data=data,
                json=json_data,
                timeout=request_timeout,
            )

            if response.status == 429 and attempt < RETRY_COUNT:
                retry_after = response.headers.get("Retry-After")

                with suppress(ValueError, TypeError):
                    delay = min(float(retry_after), 15.0)
                    await response.release()
                    await asyncio.sleep(delay)
                    continue

                await response.release()
                await asyncio.sleep(2)
                continue

            if 500 <= response.status < 600 and attempt < RETRY_COUNT:
                await response.release()
                await asyncio.sleep(2 ** attempt)
                continue

            return response

        except (
            asyncio.TimeoutError,
            aiohttp.ClientError,
        ) as exc:
            last_error = exc

            if attempt < RETRY_COUNT:
                await asyncio.sleep(2 ** attempt)

    raise last_error or RuntimeError("HTTP request failed")


async def download_binary_to_file(
    url: str,
    target: Path,
    *,
    headers: dict[str, str],
) -> Path:
    """Stream a remote file to disk, enforcing MAX_FILE_SIZE_BYTES.

    Shared by every download service so the size-cap and partial-file
    cleanup logic lives in exactly one place.
    """
    timeout = aiohttp.ClientTimeout(
        total=DOWNLOAD_TIMEOUT,
        connect=15,
        sock_read=DOWNLOAD_TIMEOUT,
    )

    response = await http_request_with_retry(
        "GET",
        url,
        headers=headers,
        timeout=timeout,
    )

    try:
        if response.status != 200:
            raise RuntimeError(f"Media HTTP {response.status}")

        content_length = response.headers.get("Content-Length")

        if content_length:
            with suppress(ValueError):
                if int(content_length) > MAX_FILE_SIZE_BYTES:
                    raise FileTooLargeError()

        target.parent.mkdir(parents=True, exist_ok=True)

        written = 0

        try:
            with target.open("wb") as file:
                async for chunk in response.content.iter_chunked(1024 * 1024):
                    if not chunk:
                        continue

                    written += len(chunk)

                    if written > MAX_FILE_SIZE_BYTES:
                        raise FileTooLargeError()

                    file.write(chunk)
        except Exception:
            cleanup_path(target)
            raise

        return target

    finally:
        await response.release()
