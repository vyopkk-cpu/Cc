import asyncio
import time
from contextlib import suppress

from aiogram import Bot
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from videobot import common
from videobot.database import db
from videobot.handlers import dp


async def cleanup_old_downloads() -> None:
    common.ensure_download_dir()

    cutoff = time.time() - (24 * 60 * 60)

    for item in common.DOWNLOAD_DIR.iterdir():
        try:
            if item.stat().st_mtime < cutoff:
                common.cleanup_path(item)
        except FileNotFoundError:
            pass
        except Exception:
            common.logger.exception("Failed old download cleanup: %s", item)


async def on_startup(bot: Bot) -> None:
    common.ensure_download_dir()

    await db.initialize()
    await cleanup_old_downloads()

    with suppress(Exception):
        me = await bot.get_me()
        common.bot_username = me.username

    common.logger.info(
        "Bot started | admins=%s | max_concurrent=%s | username=@%s",
        len(common.ADMIN_IDS),
        common.MAX_CONCURRENT_DOWNLOADS,
        common.bot_username,
    )


async def on_shutdown(bot: Bot) -> None:
    tasks = list(common.active_users.values())

    for task in tasks:
        task.cancel()

    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)

    await common.close_http_session()

    common.logger.info("Bot stopped")


async def main() -> None:
    common.ensure_download_dir()

    bot = Bot(
        token=common.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )

    dp.startup.register(on_startup)
    dp.shutdown.register(on_shutdown)

    try:
        await dp.start_polling(
            bot,
            allowed_updates=dp.resolve_used_update_types(),
        )
    finally:
        await bot.session.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        common.logger.info("Stopped by user")
